package particle_version10_steering_cohesion;

public interface Verhalten {
   public void update();
}
