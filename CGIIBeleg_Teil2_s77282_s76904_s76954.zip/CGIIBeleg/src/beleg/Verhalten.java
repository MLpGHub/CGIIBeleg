package beleg;

public interface Verhalten {
	public void update();
}
