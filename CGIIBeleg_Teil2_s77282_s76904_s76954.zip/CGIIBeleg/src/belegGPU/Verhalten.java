package belegGPU;

public interface Verhalten {
	public void update();
}
