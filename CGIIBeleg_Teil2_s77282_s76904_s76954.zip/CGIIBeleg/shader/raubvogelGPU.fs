varying vec4 vcolor;

void main() {
	gl_FragColor = vcolor;
	
}