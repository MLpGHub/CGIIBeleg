varying vec4 color;

void main() {
	gl_FragColor = color; //vec4(0, 0.8, 0.6, 1);
}
