void main() {
	gl_FragColor = vec4(0.8f, 0.8f, 0.3f, 1);
}