package swarming.behavior;

public interface Behavior {

    public void update();
}
